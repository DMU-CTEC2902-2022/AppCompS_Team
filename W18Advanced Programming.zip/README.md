# AppCompS
Individual Presentation <br>
Week 25 Lab Session (w/c: 21/03/22) <br>
Final Project Submission <br>
Friday 15th April 2022 (Week 30), 16:00 (4pm) <br>
